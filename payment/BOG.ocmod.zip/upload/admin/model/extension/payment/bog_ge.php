<?php
class ModelExtensionPaymentBogGe extends Model {

	public function install() {
		$this->db->query("
   CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "bog` (
  `bog_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `bog_order_id` int(11) NOT NULL DEFAULT '0',
  `bog_hash` varchar(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bog_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
");

}

	public function uninstall() {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "bog`;");
	}

	public function getOrder($order_id) {

		$qry = $this->db->query("SELECT bog_order_id, bog_hash FROM `" . DB_PREFIX . "bog` WHERE `order_id` = '" . (int)$order_id . "' ");

		if ($qry->num_rows) {
			$order = $qry->row;
			return $order;
		} else {
			return false;
		}
	}


}