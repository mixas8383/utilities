<?php
class Controllerextensionpaymentbogge extends Controller {
	private $error = array();

	public function index() {

		$this->load->language('extension/payment/bog_ge');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		$this->load->model('extension/payment/bog_ge');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {

			$this->model_setting_setting->editSetting('payment_bog_ge', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_sort_order'] = $this->language->get('text_sort_order');
		$data['text_bog_join'] = $this->language->get('text_bog_join');
		$data['text_minimum_total'] = $this->language->get('text_minimum_total');
		$data['text_all_geo_zones'] = $this->language->get('text_all_geo_zones');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_loading'] = $this->language->get('text_loading');
		$data['text_geo_zone'] = $this->language->get('text_geo_zone');
		$data['text_status'] = $this->language->get('text_status');
		$data['text_currency'] = $this->language->get('text_currency');

		$data['tab_api'] = $this->language->get('tab_api');
		$data['tab_general'] = $this->language->get('tab_general');
		$data['tab_order_status'] = $this->language->get('tab_order_status');
		$data['tab_instruction'] = $this->language->get('tab_instruction');


		$data['text_pending'] = $this->language->get('text_pending');
		$data['text_process'] = $this->language->get('text_process');
		$data['text_hold'] = $this->language->get('text_hold');
		$data['text_cancel'] = $this->language->get('text_cancel');
		$data['text_complete'] = $this->language->get('text_complete');
		$data['text_decline'] = $this->language->get('text_decline');






		$data['text_mslogan'] = $this->language->get('text_mslogan');
		$data['text_mlogo'] = $this->language->get('text_mlogo');
		$data['text_language'] = $this->language->get('text_language');
		$data['text_backLink'] = $this->language->get('text_backLink');



		$data['entry_merchant_id'] = $this->language->get('entry_merchant_id');
		$data['entry_access_secret'] = $this->language->get('entry_access_secret');
		$data['entry_pending_status'] = $this->language->get('entry_pending_status');





		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_save'] = $this->language->get('button_save');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['error_merchant_id'])) {
			$data['error_merchant_id'] = $this->error['error_merchant_id'];
		} else {
			$data['error_merchant_id'] = '';
		}

		if (isset($this->error['error_access_key'])) {
			$data['error_access_key'] = $this->error['error_access_key'];
		} else {
			$data['error_access_key'] = '';
		}

		if (isset($this->error['error_access_secret'])) {
			$data['error_access_secret'] = $this->error['error_access_secret'];
		} else {
			$data['error_access_secret'] = '';
		}



		if (isset($this->error['error_curreny'])) {
			$data['error_curreny'] = $this->error['error_curreny'];
		} else {
			$data['error_curreny'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true),
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_payment'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true),
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/bog_ge', 'user_token=' . $this->session->data['user_token'], true),
		);


        $data['action'] = $this->url->link('extension/payment/bog_ge', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);


		if (isset($this->request->post['payment_bog_ge_merchant_id'])) {
			$data['payment_bog_ge_merchant_id'] = $this->request->post['payment_bog_ge_merchant_id'];
		} elseif ($this->config->get('payment_bog_ge_merchant_id')) {
			$data['payment_bog_ge_merchant_id'] = $this->config->get('payment_bog_ge_merchant_id');
		} else {
			$data['payment_bog_ge_merchant_id'] = '';
		}


		if (isset($this->request->post['payment_bog_ge_access_secret'])) {
			$data['payment_bog_ge_access_secret'] = $this->request->post['payment_bog_ge_access_secret'];
		} elseif ($this->config->get('payment_bog_ge_access_secret')) {
			$data['payment_bog_ge_access_secret'] = $this->config->get('payment_bog_ge_access_secret');
		} else {
			$data['payment_bog_ge_access_secret'] = '';
		}

		if (isset($this->request->post['payment_bog_ge_mslogan'])) {
			$data['payment_bog_ge_mslogan'] = $this->request->post['payment_bog_ge_mslogan'];
		} elseif ($this->config->get('payment_bog_ge_mslogan')) {
			$data['payment_bog_ge_mslogan'] = $this->config->get('payment_bog_ge_mslogan');
		} else {
			$data['payment_bog_ge_mslogan'] = '';
		}

		if (isset($this->request->post['payment_bog_ge_mlogo'])) {
			$data['payment_bog_ge_mlogo'] = $this->request->post['payment_bog_ge_mlogo'];
		} elseif ($this->config->get('payment_bog_ge_mlogo')) {
			$data['payment_bog_ge_mlogo'] = $this->config->get('payment_bog_ge_mlogo');
		} else {
			$data['payment_bog_ge_mlogo'] = '';
		}

		if (isset($this->request->post['payment_bog_ge_language'])) {
			$data['payment_bog_ge_language'] = $this->request->post['payment_bog_ge_language'];
		} elseif ($this->config->get('payment_bog_ge_language')) {
			$data['payment_bog_ge_language'] = $this->config->get('payment_bog_ge_language');
		} else {
			$data['payment_bog_ge_language'] = 'GE';
		}




		if (isset($this->request->post['payment_bog_ge_pending_status'])) {
			$data['payment_bog_ge_pending_status'] = $this->request->post['payment_bog_ge_pending_status'];
		} elseif ($this->config->get('payment_bog_ge_pending_status')) {
			$data['payment_bog_ge_pending_status'] = $this->config->get('payment_bog_ge_pending_status');
		} else {
			$data['payment_bog_ge_pending_status'] = '0';
		}


		$data['back_url'] = HTTPS_CATALOG . 'index.php?route=extension/payment/bog_ge/info';
		$data['callback_url'] = HTTPS_CATALOG . 'index.php?route=extension/payment/bog_ge/callback';

		if (isset($this->request->post['payment_bog_ge_minimum_total'])) {
			$data['payment_bog_ge_minimum_total'] = $this->request->post['payment_bog_ge_minimum_total'];
		} elseif ($this->config->get('payment_bog_ge_minimum_total')) {
			$data['payment_bog_ge_minimum_total'] = $this->config->get('payment_bog_ge_minimum_total');
		} else {
			$data['payment_bog_ge_minimum_total'] = '0.00';
		}

		if (isset($this->request->post['payment_bog_ge_geo_zone'])) {
			$data['payment_bog_ge_geo_zone'] = $this->request->post['payment_bog_ge_geo_zone'];
		} elseif ($this->config->get('payment_bog_ge_geo_zone')) {
			$data['payment_bog_ge_geo_zone'] = $this->config->get('payment_bog_ge_geo_zone');
		} else {
			$data['payment_bog_ge_geo_zone'] = '0';
		}



		if (isset($this->request->post['payment_bog_ge_sort_order'])) {
			$data['payment_bog_ge_sort_order'] = $this->request->post['payment_bog_ge_sort_order'];
		} elseif ($this->config->get('payment_bog_ge_sort_order')) {
			$data['payment_bog_ge_sort_order'] = $this->config->get('payment_bog_ge_sort_order');
		} else {
			$data['payment_bog_ge_sort_order'] = '0';
		}

		if (isset($this->request->post['payment_bog_ge_status'])) {
			$data['payment_bog_ge_status'] = $this->request->post['payment_bog_ge_status'];
		} elseif ($this->config->get('payment_bog_ge_status')) {
			$data['payment_bog_ge_status'] = $this->config->get('payment_bog_ge_status');
		} else {
			$data['payment_bog_ge_status'] = '0';
		}


		if (isset($this->request->post['payment_bog_ge_currency'])) {
			$data['payment_bog_ge_currency'] = $this->request->post['payment_bog_ge_currency'];
		} elseif ($this->config->get('payment_bog_ge_currency')) {
			$data['payment_bog_ge_currency'] = $this->config->get('payment_bog_ge_currency');
		} else {
			$data['payment_bog_ge_currency'] = 'GEL';
		}


		if (isset($this->request->post['payment_bog_ge_completed_status'])) {
			$data['payment_bog_ge_completed_status'] = $this->request->post['payment_bog_ge_completed_status'];
		} elseif ($this->config->get('payment_bog_ge_completed_status')) {
			$data['payment_bog_ge_completed_status'] = $this->config->get('payment_bog_ge_completed_status');
		} else {
			$data['payment_bog_ge_completed_status'] = '';
		}

		if (isset($this->request->post['payment_bog_ge_process_status'])) {
			$data['payment_bog_ge_process_status'] = $this->request->post['payment_bog_ge_process_status'];
		} elseif ($this->config->get('payment_bog_ge_process_status')) {
			$data['payment_bog_ge_process_status'] = $this->config->get('payment_bog_ge_process_status');
		} else {
			$data['payment_bog_ge_process_status'] = '';
		}

		if (isset($this->request->post['payment_bog_ge_pending_status'])) {
			$data['payment_bog_ge_pending_status'] = $this->request->post['payment_bog_ge_pending_status'];
		} elseif ($this->config->get('payment_bog_ge_pending_status')) {
			$data['payment_bog_ge_pending_status'] = $this->config->get('payment_bog_ge_pending_status');
		} else {
			$data['payment_bog_ge_pending_status'] = '';
		}


        if (isset($this->request->post['payment_bog_ge_declined_status'])) {
			$data['payment_bog_ge_declined_status'] = $this->request->post['payment_bog_ge_declined_status'];
		} elseif ($this->config->get('payment_bog_ge_declined_status')) {
			$data['payment_bog_ge_declined_status'] = $this->config->get('payment_bog_ge_declined_status');
		} else {
			$data['payment_bog_ge_declined_status'] = '';
		}

		if (isset($this->request->post['payment_bog_ge_canceled_status'])) {
			$data['payment_bog_ge_canceled_status'] = $this->request->post['payment_bog_ge_canceled_status'];
		} elseif ($this->config->get('payment_bog_ge_canceled_status')) {
			$data['payment_bog_ge_canceled_status'] = $this->config->get('payment_bog_ge_canceled_status');
		} else {
			$data['payment_bog_ge_canceled_status'] = '';
		}

       if ($this->config->get('config_secure')){
		$image_url= HTTPS_CATALOG.'image/';
		}else{
		$image_url= HTTP_CATALOG.'image/';
		}

        if (isset($this->request->post['payment_bog_ge_mlogo'])) {
			$data['payment_bog_ge_mlogo'] = $this->request->post['payment_bog_ge_mlogo'];
		} elseif ($this->config->get('payment_bog_ge_mlogo')) {
			$data['payment_bog_ge_mlogo'] = $this->config->get('payment_bog_ge_mlogo');
		} else {
			$data['payment_bog_ge_mlogo'] = $image_url.$this->config->get('config_logo');
		}

		$this->load->model('tool/image');

	    if ($this->config->get('config_secure')){
		$image_l= str_replace(HTTPS_CATALOG.'image/','',$this->config->get('payment_bog_ge_mlogo'));
		}else{
		$image_l= str_replace(HTTP_CATALOG.'image/','',$this->config->get('payment_bog_ge_mlogo'));
		}
	    if ($this->config->get('payment_bog_ge_mlogo') && is_file(DIR_IMAGE . $image_l)) {
			$data['thumb'] = $this->model_tool_image->resize($image_l, 50, 50);
			$data['thumb_on'] =1;
		} else {
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 50, 50);
			$data['thumb_on'] =0;
		}




		$this->load->model('localisation/geo_zone');
		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();
		$this->load->model('localisation/order_status');
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/bog_ge', $data));
	}

	public function install() {
		$this->load->model('extension/payment/bog_ge');
		$this->model_extension_payment_bog_ge->install();
	}

	public function uninstall() {
		$this->load->model('extension/payment/bog_ge');
		$this->model_extension_payment_bog_ge->uninstall();
	}



	protected function validate() {

		$this->load->model('localisation/currency');

		if (!$this->user->hasPermission('modify', 'extension/payment/bog_ge')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

	    if (!$this->request->post['payment_bog_ge_merchant_id']) {
			$this->error['error_merchant_id'] = $this->language->get('error_merchant_id');
		}

		if (!$this->request->post['payment_bog_ge_access_secret']) {
			$this->error['error_access_secret'] = $this->language->get('error_access_secret');
		}


		/*if (!$this->request->post['payment_bog_ge_mslogan']) {
			$this->error['error_mslogan'] = $this->language->get('error_mslogan');
		}*/


		/*if (!$this->request->post['payment_bog_ge_mlogo']) {
			$this->error['error_bog_mlogo'] = $this->language->get('error_bog_mlogo');
		}*/


		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}
}