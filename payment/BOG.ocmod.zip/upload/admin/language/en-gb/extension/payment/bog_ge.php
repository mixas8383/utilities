<?php
//Headings
$_['heading_title']                 = 'bog';

//Text
$_['text_success']                  = 'Success: You have modified bog payment module!';
$_['text_language']					= 'Language';
$_['text_mslogan']                  = 'Slogan';
$_['text_mlogo']					= 'Logo URL';
$_['text_all_geo_zones']            = 'All Geo Zones';
$_['text_edit']						= 'Edit bog';
$_['text_payment']					= 'Payments';
$_['text_backLink']					= 'Back link';
$_['text_currency']					= 'Currency';

 
$_['text_bog_ge']         = '<a href="https://www.bog.com" target="_blank" ><img src="view/image/payment/bog_ge.png" alt="bog" title="bog"  /></a>';
$_['text_bog_join']              = '<a href="https://www.bog.com/register" target="_blank" title="bog - თქვენი ელექტრონული საფულე"><u>bog - თქვენი ელექტრონული საფულე</u></a>';
$_['text_minimum_total']            = 'Minimum Order Total';
$_['text_geo_zone']                 = 'Geo Zone';
$_['text_status']                   = 'Status';
$_['text_sort_order']               = 'Sort Order';


//Tabs
$_['tab_api']               = 'API Details';
$_['tab_general']           = 'General';
$_['tab_order_status']      = 'Order Status';
$_['tab_instruction']       = 'Instructions';

//status
$_['text_pending']       = 'Pending Status';
$_['text_process']       = 'Process Status';
$_['text_hold']       = 'On Hold Status';
$_['text_cancel']       = 'Canceled Status';
$_['text_decline']       = 'Declined Status';
$_['text_complete']       = 'Completed Status';


// Columns
$_['column_status']                 = 'Status';

//entry
$_['entry_merchant_id']             = 'bog Merchant ID';
$_['entry_access_secret']           = 'Secret Key';
$_['entry_pending_status']          = 'Pending Order Status';


// Errors
$_['error_permission']              = 'You do not have permissions to modify this module';
$_['error_merchant_id']			    = 'Merchant ID is required';
$_['error_bog_mlogo']			= 'Mlogo is required';
$_['error_access_secret']		    = 'Secret Key is required';
$_['error_mslogan']		        	= 'Mslogan is required';

// Buttons
$_['button_capture']				= 'Capture';
$_['button_refund']					= 'Refund';
$_['button_cancel']					= 'Cancel';
