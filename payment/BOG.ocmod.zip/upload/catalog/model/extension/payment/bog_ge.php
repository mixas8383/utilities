<?php
class ModelExtensionPaymentBogGe extends Model {



    public function addOrder($order_id, $data=array()) {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "unipay` SET `order_id` = '" . (int)$order_id . "', `unipay_order_id` = '" . $data['uorderid'] . "', `unipay_hash` = '" . $data['hash']. "' ");
    }



    public function getOrder($order_id) {

        $qry = $this->db->query("SELECT * FROM `" . DB_PREFIX . "unipay` WHERE `order_id` = '" . (int)$order_id . "' LIMIT 1");

        if ($qry->num_rows) {
            return true;
        } else {
            return false;
        }
    }








    public function sendCurl($url, $parameters) {
        $query = $this->getParametersAsString($parameters);

        $curl = curl_init($url);

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_PORT, 443);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($curl, CURLOPT_USERAGENT, $this->request->server['HTTP_USER_AGENT']);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $query);
        curl_setopt($curl, CURLOPT_HEADER, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($curl);
        curl_close($curl);

        list($other, $responseBody) = explode("\r\n\r\n", $response, 2);
        $other = preg_split("/\r\n|\n|\r/", $other);

        list($protocol, $code, $text) = explode(' ', trim(array_shift($other)), 3);

        return array('Status' => (int)$code, 'ResponseBody' => $responseBody);
    }

    public function getMethod($address, $total) {
        $this->load->language('extension/payment/bog_ge');

        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('bog_ge_geo_zone') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");

        if ($this->config->get('bog_ge_minimum_total') > $total) {
            $status = false;
        } elseif (!$this->config->get('bog_ge_geo_zone')) {
            $status = true;
        } elseif ($query->num_rows) {
            $status = true;
        } else {
            $status = false;
        }



        $method_data = array();

        if ($status) {
            $method_data = array(
                'code'       => 'bog_ge',
                'title'      => $this->language->get('text_title'),
                'terms'      => '',
                'sort_order' => $this->config->get('bog_ge_sort_order')
            );
        }

        return $method_data;

    }

    private function getParametersAsString(array $parameters) {
        $queryParameters = array();
        foreach ($parameters as $key => $value) {
            $queryParameters[] = $key . '=' . $this->urlencode($value);
        }
        return implode('&', $queryParameters);
    }


}
