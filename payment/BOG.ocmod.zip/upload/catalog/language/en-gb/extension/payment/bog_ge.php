<?php
// Heading
$_['heading_title']				= 'BOG | VISA | MasterCard | AMEX';
$_['text_title']			= 'BOG | VISA | MasterCard | AMEX';

// Text
$_['text_back']					= 'Back';
$_['text_cart']					= 'Cart';
$_['text_confirm']				= 'Confirm';
$_['text_continue']				= 'Continue';
$_['text_tax_other']			= 'Taxes / Other handling fees';
$_['text_success_title']		= 'Your order has been placed!';
$_['text_payment_success']		= 'Your order was successfully placed. Order details are below';
$_['error_minimum']             = 'Minimum order amount for BOG is %s!';