<?php

class Controllerextensionpaymentbogge extends Controller
{
    public function index()
    {
        $this->load->language('extension/payment/bog_ge');
        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('extension/payment/bog_ge');

        $data['button_confirm'] = $this->language->get('button_confirm');
        $data['text_loading'] = $this->language->get('text_loading');
        $data['continue'] = $this->url->link('checkout/success');

        if ($this->config->get('bog_ge_minimum_total') > 0 && $this->config->get('bog_ge_minimum_total') > $this->cart->getTotal()) {
            $this->failure(sprintf($this->language->get('error_minimum'), $this->currency->format($this->config->get('bog_ge_minimum_total'))));
        }

        $data['heading_title'] = $this->language->get('heading_title');
        $data['heading_address'] = $this->language->get('heading_address');
        $data['text_back'] = $this->language->get('text_back');
        $data['text_cart'] = $this->language->get('text_cart');
        $data['text_continue'] = $this->language->get('text_continue');
        $data['error_shipping'] = $this->language->get('error_shipping');
        $data['error_shipping_address'] = $this->language->get('error_shipping_address');
        $data['error_shipping_methods'] = $this->language->get('error_shipping_methods');
        $data['error_no_shipping_methods'] = $this->language->get('error_no_shipping_methods');


        $data['cart'] = $this->url->link('checkout/cart');
        $data['text_cart'] = $this->language->get('text_cart');


        return $this->load->view('extension/payment/bog_ge', $data);


    }


    public function payment()
    {

        $arr = array();
        if (isset($this->session->data['order_id'])) {
            $url = "https://api.unipay.com/checkout/createorder";
            $this->load->model('checkout/order');
            $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
            $products = array();
            $products1 = array();
            $description = array();
            $i = 0;


            $this->load->model('catalog/product');
            $this->load->model('catalog/manufacturer');

            foreach ($this->cart->getProducts() as $product) {
                $code = '';
                $manufacturer = '';
                $opts = '';
                $product_info = $this->model_catalog_product->getProduct($product['product_id']);
                $products[] = (number_format($product['price'], 2, '.', '') * 100) . '|' . $product['quantity'] . '|' . $product['name'] . '|';

                if ($this->config->get('bog_ge_product_code') == 'model') {
                    $code = $product['model'];
                } else if ($this->config->get('bog_ge_product_code')) {

                    if ($product_info[$this->config->get('bog_ge_product_code')]) {
                        $code = $product_info[$this->config->get('bog_ge_product_code')];
                    }
                }
                if ($this->config->get('bog_ge_manufacturer') == 1) {
                    $manufacturer_info = $this->model_catalog_manufacturer->getManufacturer($product_info['manufacturer_id']);
                    if ($manufacturer_info) {
                        $manufacturer = $manufacturer_info['name'];
                    }
                }


                foreach ($product['option'] as $opt) {
                    $opts [] = $opt['name'] . ' ' . $opt['value'];
                }
                if ($this->config->get('bog_ge_product_options') && !$this->config->get('bog_ge_product_code') && !$this->config->get('bog_ge_manufacturer')) {
                    if ($product['option']) {

                        $description[] = implode(', ', $opts);
                    }
                } else if ($this->config->get('bog_ge_product_options') && $this->config->get('bog_ge_product_code') && !$this->config->get('bog_ge_manufacturer')) {
                    $description[] = implode(', ', $opts) . ',  ' . $code;
                } else if ($this->config->get('bog_ge_product_options') && $this->config->get('bog_ge_product_code') && $this->config->get('bog_ge_manufacturer')) {
                    $description[] = implode(', ', $opts) . '  ' . $code . ', ' . $manufacturer;
                } else if (!$this->config->get('bog_ge_product_options') && $this->config->get('bog_ge_product_code') && $this->config->get('bog_ge_manufacturer')) {
                    $description[] = $code . ', ' . $manufacturer;
                } else if (!$this->config->get('bog_ge_product_options') && !$this->config->get('bog_ge_product_code') && $this->config->get('bog_ge_manufacturer')) {
                    $description[] = $manufacturer;
                } else if (!$this->config->get('bog_ge_product_options') && $this->config->get('bog_ge_product_code') && !$this->config->get('bog_ge_manufacturer')) {
                    $description[] = $code;
                } else {
                    if ($product['option']) {
                        $options_row = implode(', ', $opts);
                        $description[] = $options_row;
                    } else {
                        $description[] = '';
                    }
                }


                $products1[] = $product['name'];
                $i++;
            }


            if (count($products) > 1) {

                $arr = array(
                    "MerchantID" => $this->config->get('payment_bog_ge_merchant_id'),
                    "MerchantOrderID" => $this->session->data['order_id'],
                    "OrderPrice" => number_format($order_info['total'], 2, '.', '') * 100,
                    "OrderCurrency" => $this->config->get('payment_bog_ge_currency'),
                    "BackLink" => base64_encode($this->url->link('extension/payment/bog_ge/info&ordercode=' . $this->session->data['order_id'], '', 'SSL')),
                    "Mslogan" => $this->config->get('payment_bog_ge_mslogan'),
                    "Mslogo" => $this->config->get('payment_bog_ge_mlogo'),
                    "Language" => $this->config->get('payment_bog_ge_language')
                );
                $hash = array('Hash' => md5($this->config->get('payment_bog_ge_access_secret') . '|' . implode('|', $arr)), "Items" => $products, "OrderDescription" => $description);
            } else {

                $arr = array(
                    "MerchantID" => $this->config->get('payment_bog_ge_merchant_id'),
                    "MerchantOrderID" => $this->session->data['order_id'],
                    "OrderPrice" => number_format($order_info['total'], 2, '.', '') * 100,
                    "OrderCurrency" => $this->config->get('payment_bog_ge_currency'),
                    "OrderName" => $products1[0],
                    "OrderDescription" => $description[0],
                    "BackLink" => base64_encode($this->url->link('extension/payment/bog_ge/info&ordercode=' . $this->session->data['order_id'], '', 'SSL')),
                    "Mslogan" => $this->config->get('payment_bog_ge_mslogan'),
                    "Mslogo" => $this->config->get('payment_bog_ge_mlogo'),
                    "Language" => $this->config->get('payment_bog_ge_language')
                );
                $hash = array('Hash' => md5($this->config->get('payment_bog_ge_access_secret') . '|' . implode('|', $arr)));

            }


            $result = array_merge($hash, $arr);
            $content = json_encode($result);

            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_PORT, 443);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($curl, CURLOPT_USERAGENT, $this->request->server['HTTP_USER_AGENT']);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
            curl_setopt($curl, CURLOPT_HEADER, false);

            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $json_response = curl_exec($curl);

            $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);

            if ($status != 200) {
                die("Error: call to URL $url failed with status $status, response $json_response, curl_error " . curl_error($curl) . ", curl_errno " . curl_errno($curl));
            }


            curl_close($curl);
            $response = json_decode($json_response, true);
            if ($response['Errorcode'] == 0) {
                $this->response->redirect($response['Data']['Checkout']);

            } else {
                $this->response->redirect($this->url->link('checkout/checkout'));
            }

        } else {
            $this->response->redirect($this->url->link('checkout/checkout'));
        }

    }


    public function callback()
    {
        $this->load->model('checkout/order');
        $this->load->model('extension/payment/bog_ge');
        $SecretKey = $this->config->get('payment_bog_ge_access_secret');
        $Hash = $this->request->get['Hash'];
        $UnipayOrderID = $this->request->get['UnipayOrderID'];
        $MerchantOrderID = $this->request->get['MerchantOrderID'];
        $Status = $this->request->get['Status'];
        $Reason = $this->request->get['Reason'];
        $CalculateHash = $UnipayOrderID . '|' . $MerchantOrderID . '|' . $Status . '|' . $SecretKey;
        $CalculateHash = md5($CalculateHash);
//echo $CalculateHash;
        $data['hash'] = $Hash;
        $data['uorderid'] = $UnipayOrderID;
        $order_info = $this->model_checkout_order->getOrder($MerchantOrderID);

        if ($Hash != $CalculateHash) {
            throw new Exception('this_is_not_unipay_response', 500);
        }


        if ($order_info && ($Hash == $CalculateHash) && ($Status == 'COMPLETED')) {
            $isorder = $this->model_extension_payment_bog_ge->getOrder($MerchantOrderID);
            if ($order_info['order_status_id'] != $this->config->get('payment_bog_ge_completed_status')) {
                $this->model_checkout_order->addOrderHistory($MerchantOrderID, $this->config->get('payment_bog_ge_completed_status'));
            }
            if (!$isorder) {
                $this->model_extension_payment_bog_ge->addOrder($MerchantOrderID, $data);
            }
            $this->response->addHeader('HTTP/1.1 200 OK');
//echo 'OK';	
        }


        if ($order_info && ($Hash == $CalculateHash) && ($Status == 'PENDING')) {
            $isorder = $this->model_extension_payment_bog_ge->getOrder($MerchantOrderID);
            if ($order_info['order_status_id'] != $this->config->get('payment_bog_ge_pending_status')) {
                $this->model_checkout_order->addOrderHistory($MerchantOrderID, $this->config->get('payment_bog_ge_pending_status'));
            }
            if (!$isorder) {
                $this->model_extension_payment_bog_ge->addOrder($MerchantOrderID, $data);
            }
            $this->response->addHeader('HTTP/1.1 200 OK');
//echo 'OK';	
        }

        if ($order_info && ($Hash == $CalculateHash) && ($Status == 'DECLINED')) {
            $isorder = $this->model_extension_payment_bog_ge->getOrder($MerchantOrderID);
            if ($order_info['order_status_id'] != $this->config->get('payment_bog_ge_declined_status')) {
                $this->model_checkout_order->addOrderHistory($MerchantOrderID, $this->config->get('payment_bog_ge_declined_status'));
            }
            if (!$isorder) {
                $this->model_extension_payment_bog_ge->addOrder($MerchantOrderID, $data);
            }
            $this->response->addHeader('HTTP/1.1 200 OK');
//echo 'OK';	
        }

        if ($order_info && ($Hash == $CalculateHash) && ($Status == 'PROCESS')) {
            $isorder = $this->model_extension_payment_bog_ge->getOrder($MerchantOrderID);
            if ($order_info['order_status_id'] != $this->config->get('payment_bog_ge_process_status')) {
                $this->model_checkout_order->addOrderHistory($MerchantOrderID, $this->config->get('payment_bog_ge_process_status'));
            }
            if (!$isorder) {
                $this->model_extension_payment_bog_ge->addOrder($MerchantOrderID, $data);
            }
            $this->response->addHeader('HTTP/1.1 200 OK');
//echo 'OK';	
        }

        if ($order_info && ($Hash == $CalculateHash) && ($Status == 'CANCELED')) {
            $isorder = $this->model_extension_payment_bog_ge->getOrder($MerchantOrderID);
            if ($order_info['order_status_id'] != $this->config->get('payment_bog_ge_canceled_status')) {
                $this->model_checkout_order->addOrderHistory($MerchantOrderID, $this->config->get('payment_bog_ge_canceled_status'));
            }
            if (!$isorder) {
                $this->model_extension_payment_bog_ge->addOrder($MerchantOrderID, $data);
            }
            $this->response->addHeader('HTTP/1.1 200 OK');
//echo 'OK';	
        }


    }


    public function info()
    {

        if (isset($this->request->get['ordercode'])) {
            $order_id = $this->request->get['ordercode'];
        } else {
            $order_id = 0;
        }


        $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($order_id);

        if (!$order_info) {
            $this->response->redirect($this->url->link('checkout/checkout'));
        }

        if (($order_info['order_status_id'] == $this->config->get('payment_bog_ge_process_status')) || ($order_info['order_status_id'] == $this->config->get('payment_bog_ge_pending_status')) || ($order_info['order_status_id'] == $this->config->get('payment_bog_ge_completed_status'))) {

            $this->response->redirect($this->url->link('checkout/success'));
        } else {
            $this->response->redirect($this->url->link('checkout/checkout'));
        }


    }


}